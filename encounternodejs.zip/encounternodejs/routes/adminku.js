var multer = require('multer');

exports.login = function (req, res) {
    var message = '';
    var sess    = req.session;
    var md5     = require('md5');

    if (req.method == 'POST') {
        // jika route method-nya adalah POST, lakukan proses autentikasi login!

        // 1. tangkap nilai dari atribut pada pada body
        var post = req.body;

        // 2. tangkap nilai atribut name dari form input username dan password
        var name = post.username;
        // var pass = post.password;

        var pass = md5(post.password);

        //  3. lakukan koneksi database dan query data admin 
        req.getConnection(function (err, connect) {
            var sql   = "SELECT id_admin, username, name, admin_level FROM admin_tbl WHERE username= '"+name+"' AND password= '"+pass+"'";
            var query = connect.query(sql, function (err, results) {
                if (results.length) {
                    //  jika hasil query ada, maka daftarkan session dan alihkan ke halaman home admin! 
                    req.session.adminId = results[0].id_admin;
                    req.session.admin   = results[0];
                    console.log(results[0].id_admin);
                    res.redirect('./home');
                } else {
                    //  jika hasil query tidak ada, kirimkan error message dan tampilkan layout form login!
                    message = 'Username or Password is Incorrect! Please try again.';
                    res.render('./admin/index', {
                        message : message
                    }); 
                }
            });
        }); 
    } else {
        // jika route method-nya bukan POST, tampilkan layout form login!
        res.render('./admin/index', {
            message: message
        });
    } 
}

exports.home = function (req, res) {
    var admin   = req.session.admin;
    var adminId = req.session.adminId;
    console.log('id_admin= ' + adminId);

    if (adminId == null) {
        res.redirect('/express/admin/login');
        return;
    }

    req.getConnection(function (err, connect){
        var sql = "SELECT * FROM product ORDER BY createdate DESC";

        var query = connect.query(sql, function (err, results) {
            // jika koneksi dan query berhasil, tampilkan home admin!
            res.render('./admin/home', {
                pathname: 'home',
                data: results
            });
        });
    });
}

exports.products = function (req, res) {
    var admin   = req.session.admin;
    var adminId = req.session.adminId;
    console.log('id_admin= ' + adminId);

    if (adminId == null) {
        res.redirect('/express/admin/login');
        return;
    }

    req.getConnection(function (err, connect){
        var sql = "SELECT * FROM product ORDER BY createdate DESC";

        var query = connect.query(sql, function (err, results) {
            // jika koneksi dan query berhasil, tampilkan home admin!
            res.render('./admin/home', {
                pathname: 'products',
                data: results
            });
        });
    });
}

exports.add_products = function (req, res) {
    var admin   = req.session.admin;
    var adminId = req.session.adminId;
    console.log('id_admin= ' + adminId);

    if (adminId == null) {
        res.redirect('/express/admin/login');
        return;
    }

    res.render('./admin/home', {
        pathname: 'add_products'
    });
}

exports.process_add_products = function (req, res) {
    var storage = multer.diskStorage({
        destination: './public/images',
        filename: function(req, file, callback) {
            callback(null, file.originalname);
        }
    });

    var upload = multer({ storage: storage}).single('gambar_produk');
    var date   = new Date(Date.now());

    upload(req, res, function(err) {
        if (err) {
            return res.end('Error uploading image!');
        }

        console.log(req.file);
        console.log(req.body);

        req.getConnection(function(err, connect) {
            // tangkap nilai atribut name dari tag body
            var post = {
                nama_produk: req.body.nama_produk,
                harga_product: req.body.harga_product,
                des_product: req.body.des_product,
                gambar_produk: req.file.filename,
                createdate: date
            }

            console.log(post); // untuk menampilkan data post di console
            
            var sql = "INSERT INTO product SET ?";

            var query = connect.query(sql, post, function (err, results) {
                if (err) {
                    console.log('Error input product: %s', err);
                }

                req.flash('info', 'Success add data! Data has been updated.');
                res.redirect('/express/admin/products');
            }); 
        });
    });
} 

exports.edit_products = function (req, res) {
    var admin   = req.session.admin;
    var adminId = req.session.adminId;
    console.log('id_admin= ' + adminId);

    if (adminId == null) {
        res.redirect('/express/admin/login');
        return;
    }
    
    // tangkap id_product dari  link edit
    var id_product = req.params.id_product;

    req.getConnection(function (err, connect) {
        var sql = "SELECT * FROM product WHERE id_product=?";

        var query = connect.query(sql, id_product, function (err, results) {
            if (err) {
                console.log('Error show products: %s', err);
            }

            res.render('./admin/home', {
                id_product: id_product,
                pathname: 'edit_products',
                data: results
            });
        });
    });    
}

exports.process_edit_products = function (req, res) {
    var id_product = req.params.id_product;
    
    var storage = multer.diskStorage({
        destination: './public/images',
        filename: function (req, file, callback){
            callback(null, file.originalname);
        }    
    });

    var upload = multer({ storage: storage }).single('gambar_produk');
    var date = new Date(Date.now());

    upload(req, res, function (err) {
        if (err) {
            var gambar_produk = req.body.image_old;
            console.log('Error uploading image!');
        } else if (req.file == undefined) {
            var gambar_produk = req.body.image_old;
        } else {
            var gambar_produk = req.file.filename;
        }

        console.log(req.file);
        console.log(req.body);

        req.getConnection(function (err, connect) {
            var post = {
                nama_produk: req.body.nama_produk,
                harga_product: req.body.harga_product,
                des_product: req.body.des_product,
                gambar_produk: gambar_produk,
                createdate: date
            }

            var sql = "UPDATE product SET ? WHERE id_product=?";

            var query = connect.query(sql, [post, id_product], function (err, results) {
                if (err) {
                    console.log('Error edit product: %s', err);
                }

                req.flash('info', 'Succes edit data! Data has been updated.');
                res.redirect('/express/admin/products');
            });
        })
    });
}

exports.delete_products = function (req, res) {
    var id_product = req.params.id_product;

    req.getConnection(function (err, connect) {
        var sql = "DELETE  FROM product WHERE id_product=?";

        var query = connect.query(sql, id_product, function (err, results) {
            if (err) {
                console.log('Error delete product: %s', err);
            }

            res.redirect('/express/admin/products');
        });
    });
}

